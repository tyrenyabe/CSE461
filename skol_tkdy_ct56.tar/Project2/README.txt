skol
tkdy
ct56