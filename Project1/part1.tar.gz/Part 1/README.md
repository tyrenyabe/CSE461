# Client Side
## Members
- Tyren Dakujaku-Yabe : tkdy
- Stuart Kol : skol
- Chao Tan : ct56

## Secrets (Stage 1, Stage 2, Stage 3, Stage 4)
(38, 13, 23, 3)

## How to Run
Run
```
python3 Step1.py
```