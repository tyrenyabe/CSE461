# Server Side
## Members
- Tyren Dakujaku-Yabe : tkdy
- Stuart Kol : skol
- Chao Tan : ct56

## How to Run
1. Spin up server
```
python3 Step2.py
```
2. Execute client side code. Note: The only difference between the two client side files from each part are the IP addresses.
```
python3 Step2Client.py
```
